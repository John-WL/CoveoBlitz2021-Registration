package codes.blitz.game.local_test;

import java.util.ArrayList;
import java.util.List;

import static codes.blitz.game.Application.algoV2;

public class RunAlgo {

    public static void main(String [] args) {
        List<Integer> tracks = new ArrayList<>();
        tracks.add(0);
        tracks.add(3);
        tracks.add(4);
        tracks.add(5);
        tracks.add(4);
        List<List<Integer>> items = new ArrayList<>();
        items.add(new ArrayList<>());
        items.get(0).add(0);
        items.get(0).add(1);
        items.add(new ArrayList<>());
        items.get(1).add(0);
        items.get(1).add(3);
        items.add(new ArrayList<>());
        items.get(2).add(1);
        items.get(2).add(4);
        items.add(new ArrayList<>());
        items.get(3).add(4);
        items.get(3).add(3);

        System.out.println(algoV2(tracks, items));
    }
}
