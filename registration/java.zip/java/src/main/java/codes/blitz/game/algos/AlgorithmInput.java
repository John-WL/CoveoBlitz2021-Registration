package codes.blitz.game.algos;

import java.util.List;

public class AlgorithmInput {
    public List<Integer> track;
    public List<List<Integer>> items;
}
