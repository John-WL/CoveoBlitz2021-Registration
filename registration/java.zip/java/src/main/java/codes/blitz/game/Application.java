package codes.blitz.game;

import java.util.ArrayList;
import java.util.List;

import io.javalin.Javalin;
import picocli.CommandLine;
import picocli.CommandLine.Option;

import org.json.*;

public class Application
{

  /*public static void main(String [] args) {

    List<Integer> tracks = new ArrayList<>();
    tracks.add(3);
    tracks.add(4);
    tracks.add(5);
    tracks.add(4);
    List<List<Integer>> items = new ArrayList<>();
    items.add(new ArrayList<>());
    items.get(0).add(0);
    items.get(0).add(1);
    items.add(new ArrayList<>());
    items.get(1).add(0);
    items.get(1).add(3);
    items.add(new ArrayList<>());
    items.get(2).add(1);
    items.get(2).add(4);
    items.add(new ArrayList<>());
    items.get(3).add(4);
    items.get(3).add(3);

    System.out.println(algoV1(tracks, items));
  }*/


  public static class Args {
    @Option(names = { "-p", "--port" },
        description = "set port number (default: 27178)",
        defaultValue = "27178")
    public int port;
  }

  public static void main (String [] args) {
    Args arguments = new Args();
    new CommandLine(arguments).parseArgs(args);

    Javalin app = Javalin.create(javalinConfig -> {
      javalinConfig.requestCacheSize = 1000 * 1000 * 2L;
    }).start(arguments.port);
    app.post("/microchallenge", ctx -> {

      String jsonStringInput = ctx.body();

      JSONObject jsonObject = new JSONObject(jsonStringInput);
      JSONArray trackJsonArray = jsonObject.getJSONArray("track");
      JSONArray itemsJsonArray = jsonObject.getJSONArray("items");

      List<Integer> tracks = parseTrack(trackJsonArray);
      List<List<Integer>> items = parseItems(itemsJsonArray);

      ctx.json(algoV1(tracks, items));
    });
  }


  private static List<Integer> parseTrack(JSONArray trackJsonArray) {
    List<Integer> parsedTracks = new ArrayList<>(trackJsonArray.length());

    for(int i = 0; i < trackJsonArray.length(); i++) {
      parsedTracks.add(Integer.valueOf(trackJsonArray.get(i).toString()));
    }

    return parsedTracks;
  }

  private static List<List<Integer>> parseItems(JSONArray itemsJsonArray) {
    List<List<Integer>> parsedItems = new ArrayList<>(itemsJsonArray.length());

    for(int i = 0; i < itemsJsonArray.length(); i++) {
      parsedItems.add(new ArrayList<>());
      JSONArray itemJsonArray = itemsJsonArray.getJSONArray(i);
      parsedItems.get(i).add(Integer.valueOf(itemJsonArray.get(0).toString()));
      parsedItems.get(i).add(Integer.valueOf(itemJsonArray.get(1).toString()));
    }

    return parsedItems;
  }

  private static List<Integer> algoV1(List<Integer> tracks, List<List<Integer>> items) {
    List<Integer> computedLengths = new ArrayList<>(items.size());
    List<Integer> trackLengthsFromOrigin = new ArrayList<>(tracks.size());
    int currentTrackLength = 0;
    trackLengthsFromOrigin.add(0);

    for(var track: tracks) {
      currentTrackLength += track;
      trackLengthsFromOrigin.add(currentTrackLength);
    }

    for(var item: items) {
      computedLengths.add(
              Math.abs(trackLengthsFromOrigin.get(item.get(1))
              - trackLengthsFromOrigin.get(item.get(0)))
      );
    }

    return computedLengths;
  }
}
