package codes.blitz.game.algos;

import java.util.Arrays;
import java.util.List;

public class LinearSolutionWithArraysCopyElision implements RailTransportProblem {
    @Override
    public String execute(final AlgorithmInput input) {
        int[] computedLengths = new int[input.items.size()];
        updateTracksAsLengths(input.track);

        for(int i = 0; i < input.items.size(); i++) {
            final var itemTuple = input.items.get(i);
            final int itemEnd = input.track.get(itemTuple.get(1));
            final int itemStart = input.track.get(itemTuple.get(0));
            computedLengths[i] = Math.abs(itemEnd - itemStart);
        }

        return Arrays.toString(computedLengths);
    }

    private void updateTracksAsLengths(final List<Integer> tracks) {
        int currentTrackLength = 0;
        for(int i = 0; i < tracks.size(); i++) {
            currentTrackLength += tracks.get(i);
            tracks.set(i, currentTrackLength);
        }
    }
}
