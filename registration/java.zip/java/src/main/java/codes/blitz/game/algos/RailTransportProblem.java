package codes.blitz.game.algos;

public interface RailTransportProblem {
    String execute(final AlgorithmInput input) throws Exception;
}
