package codes.blitz.game.algos;

import java.util.Arrays;
import java.util.List;

// solution in O(N)
public class LinearSolutionWithArrays implements RailTransportProblem {

    @Override
    public String execute(final AlgorithmInput input) {
        int[] computedLengths = new int[input.items.size()];
        int[] trackLengthsFromOrigin = trackLengthsFromOrigin(input.track);

        for(int i = 0; i < input.items.size(); i++) {
            computedLengths[i] =
                Math.abs(trackLengthsFromOrigin[input.items.get(i).get(1)]
                    - trackLengthsFromOrigin[input.items.get(i).get(0)]);
        }

        return Arrays.toString(computedLengths);
    }

    private int[] trackLengthsFromOrigin(final List<Integer> tracks) {
        int[] trackLengthsFromOrigin = new int[tracks.size()];

        int currentTrackLength = 0;
        for(int i = 0; i < tracks.size(); i++) {
            currentTrackLength += tracks.get(i);
            trackLengthsFromOrigin[i] = currentTrackLength;
        }

        return trackLengthsFromOrigin;
    }
}
