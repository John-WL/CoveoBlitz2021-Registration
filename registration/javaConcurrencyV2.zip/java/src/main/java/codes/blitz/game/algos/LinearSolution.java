package codes.blitz.game.algos;

import java.util.ArrayList;
import java.util.List;

// solution in O(N)
public class LinearSolution implements RailTransportProblem {

    @Override
    public List<Integer> execute(List<Integer> tracks, List<List<Integer>> items) {
        List<Integer> computedLengths = new ArrayList<>(items.size());
        List<Integer> trackLengthsFromOrigin = new ArrayList<>(tracks.size());
        int currentTrackLength = 0;

        for(var track: tracks) {
            currentTrackLength += track;
            trackLengthsFromOrigin.add(currentTrackLength);
        }

        for(var item: items) {
            computedLengths.add(
                    Math.abs(trackLengthsFromOrigin.get(item.get(1))
                            - trackLengthsFromOrigin.get(item.get(0)))
            );
        }

        return computedLengths;
    }
}
